-- CanDo submission --

Date and time: 2012-06-26 16:47:31
Name: Leighton Cline
University/Institute/Company: NC State
Email: lgcline@ncsu.edu
Filename: 384 vertex stapled.json
File type: honeycomb
Axial rise: 0.34
Helix diameter: 2.25
Axial stiffness: 1100
Bending stiffness: 230
Torsional stiffness: 460
Nick stiffness factor: 0.01
Model: coarse
Movie: yes